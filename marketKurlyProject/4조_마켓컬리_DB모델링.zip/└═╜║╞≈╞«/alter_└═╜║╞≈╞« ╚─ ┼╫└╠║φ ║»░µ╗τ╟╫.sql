ALTER TABLE product
MODIFY(
    p_name VARCHAR2(100) NOT NULL
    , p_price NUMBER DEFAULT 0 
    , p_discount NUMBER DEFAULT 0 NOT NULL --0.00~0.01~0.99~1.00
    , p_cold_type NUMBER(1) DEFAULT 1 NOT NULL --(��� 1 / ���� 2 / �õ� 3)
    , p_rdate DATE DEFAULT SYSDATE NOT NULL
);

ALTER TABLE product
ADD(
    CONSTRAINTS ck_product_p_price CHECK (p_price >= 0)
    , CONSTRAINTS ck_product_p_discount CHECK (p_discount BETWEEN 0 AND 1)
    , CONSTRAINTS ck_product_p_cold_type CHECK (p_cold_type BETWEEN 1 AND 3)
);

ALTER TABLE mk_dorder
MODIFY(
    od_count NUMBER(4) DEFAULT 1 NOT NULL
    , od_price NUMBER DEFAULT 0 NOT NULL
);

ALTER TABLE mk_dorder
ADD(
    CONSTRAINTS ck_mk_dorder_od_count CHECK (od_count BETWEEN 1 AND 9999) -- ������� ū �� > �����߻�
    , CONSTRAINTS ck_mk_dorder_od_price CHECK (od_price >= 0)
);

ALTER TABLE cart
MODIFY(
    cart_select NUMBER(1) DEFAULT 1 NOT NULL -- ���� 1 / ���þ��� 0
    , cart_count NUMBER(4) DEFAULT 1 NOT NULL
    , cart_price NUMBER DEFAULT 0 NOT NULL
    , cart_reserves NUMBER DEFAULT 0 NOT NULL
);

ALTER TABLE cart
ADD(
    CONSTRAINTS ck_cart_cart_select CHECK (cart_select IN (0, 1))
    , CONSTRAINTS ck_cart_cart_count CHECK (cart_count BETWEEN 1 AND 9999)
    , CONSTRAINTS ck_cart_cart_price CHECK (cart_price >= 0)
    , CONSTRAINTS ck_cart_cart_reserves CHECK (cart_reserves >= 0)
);

ALTER TABLE mk_order
MODIFY(
    o_date DATE DEFAULT SYSDATE NOT NULL -- ���� 1 / ���þ��� 0
    , o_price NUMBER DEFAULT 0 NOT NULL
    , o_dstate VARCHAR2(20) DEFAULT '�����Ϸ�' NOT NULL -- �ڷ��� ũ�� �ø�
    , o_rspot VARCHAR2(100) DEFAULT '�� ��' NOT NULL
    , o_message NUMBER(1) DEFAULT 0 NOT NULL -- ������� 0 / ���� 7�� 1
    , o_pay_method NOT NULL
);

ALTER TABLE mk_order
ADD(
    CONSTRAINTS ck_mk_order_o_price CHECK (o_price >= 0)
    , CONSTRAINTS ck_mk_order_o_dstate CHECK (o_dstate IN ('���� �Ϸ�', '��� �غ� ��', '��� ��', '��� �Ϸ�', '���� ���'))
    , CONSTRAINTS ck_mk_order_o_message CHECK (o_message IN (0, 1))
    , CONSTRAINTS ck_mk_order_o_pay_method CHECK (o_pay_method IN ('�ſ�ī��', '��������', '�޴���', 'īī�� ����'))
);

ALTER TABLE payment
MODIFY(
    p_method VARCHAR2(20)  NOT NULL
    , p_price NUMBER DEFAULT 0 NOT NULL
);

ALTER TABLE payment
ADD(
    CONSTRAINTS ck_payment_p_method CHECK (p_method IN ('�ſ�ī��', '��������', '�޴���', 'īī�� ����', '����', '������'))
    , CONSTRAINTS ck_payment_p_price CHECK (p_price >= 0)
);

ALTER TABLE product_img
MODIFY (
    img_code DEFAULT 1, file_path NOT NULL
);

ALTER TABLE ed_grade
ADD (
    CONSTRAINTS ck_ed_grade_dc_rate CHECK (dc_rate BETWEEN 0 AND 1)
);

ALTER TABLE wh_history
MODIFY (
    wh_date DEFAULT SYSDATE
        , count DEFAULT 1
);

ALTER TABLE wh_history
ADD (CONSTRAINT ck_wh_edate CHECK (wh_date < expiration_date)
        , CONSTRAINT ck_wh_rdate CHECK (remaining_date > 0)
        , CONSTRAINT ck_wh_count CHECK (count > 0)
);

ALTER TABLE category
ADD (
    CONSTRAINT ck_category_count CHECK (ctgr_top != ctgr_name)
);

ALTER TABLE custome_grade RENAME TO customer_grade;

ALTER TABLE customer_grade
MODIFY (
    benefits NUMBER DEFAULT 0
    , accum NUMBER DEFAULT 0 NOT NULL
    , puple_gift VARCHAR2(30) DEFAULT 'X' NOT NULL
    , double_accum NUMBER(1) DEFAULT 0 NOT NULL -- 0 or 1
);

ALTER TABLE customer_grade
ADD (
    grade_name VARCHAR2(12) NOT NULL
    , CONSTRAINTS ck_c_grade_grade CHECK (grade IN(1, 2, 3, 4, 5, 6))
    , CONSTRAINTS ck_c_grade_grade_name CHECK (grade_name IN ('�� ����', '����', '�󺥴�', 'ȭ��Ʈ', '������', '�Ϲ�'))
    , CONSTRAINTS ck_c_grade_accum CHECK (accum BETWEEN 0 AND 1)
    , CONSTRAINTS ck_c_grade_double_accum CHECK (double_accum IN(0,1))
);

ALTER TABLE coupon
MODIFY (
    cou_name VARCHAR2(100) NOT NULL
    , cou_function VARCHAR2(100) NOT NULL
    , cou_discount NUMBER DEFAULT 0 NOT NULL
);

ALTER TABLE coupon
ADD (
    cou_d_rate NUMBER(3,2) DEFAULT 0 NOT NULL
    , CONSTRAINTS ck_coupon_discount CHECK (cou_discount >= 0)
    , CONSTRAINTS ck_coupon_d_rate CHECK (cou_d_rate BETWEEN 0 AND 1)
);

ALTER TABLE sign_up
MODIFY(
    C_ID   NOT NULL  
    ,C_PWD             VARCHAR2(30)      NOT NULL
    ,C_ADDRESS         VARCHAR2(500)     NOT NULL
    ,C_EMAIL           VARCHAR2(30 CHAR) NOT NULL
    ,C_NAME            VARCHAR2(20)      NOT NULL
    ,C_BIRTHDAY        DATE              NOT NULL
    ,C_GENDER          NUMBER(1)         NOT NULL
    ,C_PHONE           NUMBER(13)        NOT NULL
    ,C_TOS             NUMBER(1)         NOT NULL
    ,C_AGECHECK        NUMBER(1)         NOT NULL
    ,C_SMSCHECK        NUMBER(1)         DEFAULT 0 NOT NULL
    ,C_EMAILCHECK      NUMBER(1)         DEFAULT 0 NOT NULL
    ,C_PERSONALAGREE   NUMBER(1)         NOT NULL
    ,C_RECOMMEND       VARCHAR2(30)      DEFAULT 'X'
    ,C_EVENTCHECK      VARCHAR2(30)      DEFAULT 'X'
);

ALTER TABLE sign_up
ADD (
    CONSTRAINTS ck_sign_up_id CHECK(REGEXP_LIKE(c_id, '\w{6,30}'))
    ,CONSTRAINTS UK_sign_up_id UNIQUE (c_id)
    ,CONSTRAINTS ck_sign_up_pw CHECK(REGEXP_LIKE(c_PWD, '[A-Za-z0-9$@!%*\?&]{10,30}'))
    ,CONSTRAINTS ck_sign_up_phone CHECK(REGEXP_LIKE(c_phone, '010-\d{4}-\d{4}'))
    ,CONSTRAINTS ck_sign_up_email CHECK(REGEXP_LIKE(c_email, '\w+@\w+\.\w+(\.\w+)?'))
    ,CONSTRAINTS ck_sign_up_gender CHECK(c_gender IN (0, 1, 2)) -- '����'0 '����'1 '���þ���'2
    ,CONSTRAINTS ck_sign_up_tos CHECK(C_TOS IN(1))
    ,CONSTRAINTS ck_sign_up_agecheck CHECK(C_AGECHECK IN(1))
    ,CONSTRAINTS ck_sign_up_smscheck CHECK(C_SMSCHECK IN(0,1))
    ,CONSTRAINTS ck_sign_up_emailcheck CHECK(C_EMAILCHECK IN(0,1))
    ,CONSTRAINTS ck_sign_up_personalagree CHECK(C_PERSONALAGREE IN(1))
);

ALTER TABLE my_coupon
MODIFY (
    mcou_end NOT NULL
    , mcou_check DEFAULT 0 NOT NULL
);
 
ALTER TABLE my_coupon
ADD (
    CONSTRAINTS ck_my_coupon_check CHECK (mcou_check IN (0, 1, 2)) -- ����� 0, �����1, ����2
);

ALTER TABLE shipping
MODIFY (
    s_address NOT NULL
    ,recipient NOT NULL
    ,telnumber NOT NULL
    ,delivery DEFAULT 0 NOT NULL
);

ALTER TABLE shipping
ADD (
    CONSTRAINTS ck_shipping_telnumber CHECK (REGEXP_LIKE(telnumber, '\d{2,3}-\d{3,4}-\d{4}'))
    ,CONSTRAINTS ck_shipping_delivery CHECK (delivery IN (0, 1)) 
);

ALTER TABLE reserves
MODIFY (
    rsv_date DEFAULT SYSDATE NOT NULL
    ,rsv_memo NOT NULL
    ,rsv_price NOT NULL
);

ALTER TABLE customer
    MODIFY (
     c_name not null  
     , c_id   not null
     , c_curlypass default 0 NOT NULL
     , c_puplebox default 0 NOT NULL
     , c_end_coupon default 0 NOT NULL
     , c_order_count default 0 NOT NULL
     , c_wish_count default 0 NOT NULL
);

ALTER TABLE customer      
     ADD (
    CONSTRAINTS ck_customer_id CHECK(REGEXP_LIKE(c_id, '\w{6,30}'))
    ,CONSTRAINTS UK_customer_id unique (c_id)
    ,CONSTRAINTS ck_customer_c_curlypass check (c_curlypass in(0,1))
    ,CONSTRAINTS ck_customer_c_puplebox check (c_puplebox in(0,1))
    ,CONSTRAINTS ck_customer_c_end_coupon check (c_end_coupon >= 0)
    ,CONSTRAINTS ck_customer_c_order_count check (c_order_count >= 0)
    ,CONSTRAINTS ck_customer_c_wish_count check (c_wish_count >= 0)
);

ALTER TABLE Question      
     MODIFY (
    Q_SYSD default sysdate
);

ALTER TABLE Question
ADD (
    CONSTRAINTS ck_qustion_state CHECK (q_state IN (0, 1))
);

ALTER TABLE review      
MODIFY (
    r_date default sysdate
    , r_help default 0 NOT NULL
    , r_check default 0 NOT NULL
);  

ALTER TABLE review      
ADD (
     CONSTRAINTS ck_review_check check (r_check >= 0)
     ,CONSTRAINTS ck_review_help check (r_help >= 0)
);

ALTER TABLE Benefits      
MODIFY (
    B_imgpath not null
    ,B_end not null
);  


