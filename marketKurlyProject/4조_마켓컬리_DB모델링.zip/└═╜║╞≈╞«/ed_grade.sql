--------------------------------------------------------
--  ������ ������ - ������-4��-27-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ED_GRADE
--------------------------------------------------------

  CREATE TABLE "SCOTT"."ED_GRADE" 
   (	"DC_RATE" NUMBER(3,2), 
	"LOW_DATE" DATE, 
	"HIGH_DATE" DATE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "SCOTT"."ED_GRADE"."DC_RATE" IS '������';
   COMMENT ON COLUMN "SCOTT"."ED_GRADE"."LOW_DATE" IS 'low�������';
   COMMENT ON COLUMN "SCOTT"."ED_GRADE"."HIGH_DATE" IS 'high�������';
   COMMENT ON TABLE "SCOTT"."ED_GRADE"  IS '������ѵ��';
REM INSERTING into SCOTT.ED_GRADE
SET DEFINE OFF;
--------------------------------------------------------
--  Constraints for Table ED_GRADE
--------------------------------------------------------

  ALTER TABLE "SCOTT"."ED_GRADE" ADD CONSTRAINT "CK_ED_GRADE_DC_RATE" CHECK (dc_rate BETWEEN 0 AND 1) ENABLE;
  ALTER TABLE "SCOTT"."ED_GRADE" MODIFY ("HIGH_DATE" NOT NULL ENABLE);
  ALTER TABLE "SCOTT"."ED_GRADE" MODIFY ("LOW_DATE" NOT NULL ENABLE);
  ALTER TABLE "SCOTT"."ED_GRADE" MODIFY ("DC_RATE" NOT NULL ENABLE);
